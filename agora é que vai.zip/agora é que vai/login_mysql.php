<?php
session_start(); //para utilizar "session" tem de estar aqui no topo e em todos os scripts
//*************************************para eliminar a variável session $_SESSION['permissao'] depois de logout******
//******evita que se introduza diretamento o link no browser e entre*******
if (!isset($_POST['username']))
	{
		header('Location:/login');
		exit();
	}
//*************************************************************************
include ($_SERVER['DOCUMENT_ROOT']."/database.php"); //script de acesso à base de dados
//******************************deteta se o user está eliminado********************************
$select = "SELECT username, del  FROM user
			WHERE username ='".$_POST['username']. "'
			AND del = 1
			LIMIT 1";
$resultado = mysqli_query ($conn, $select);
$numero_de_linhas = mysqli_num_rows($resultado);
if($numero_de_linhas==1)
	{
		$_SESSION['utilizador_eliminado']= "1";
		mysqli_close($conn);
		header('Location:/login');
		exit();
	}
//*************************************************************************************
//******************************deteta se o user existe********************************
$select = "SELECT
				username,
				shots,
				perm_id,
				lock_id,
				password
			FROM
				user
			WHERE username ='".$_POST['username']. "'
			LIMIT 1" ;
$resultado = mysqli_query($conn, $select);
$numero_de_linhas = mysqli_num_rows($resultado);
if($numero_de_linhas==0)
	{
		$_SESSION['utilizador_nao_existe']= "1";
		mysqli_close($conn);
		header('Location:/login');
		exit();
	}
//*************************************************************************************
else
//*****************deteta se tem tentativas ou se está bloqueado na descrição**********
	{
		$linha=mysqli_fetch_array($resultado);
		if($linha["shots"]==0 || $linha["lock_id"]!=0)
			{
			$_SESSION['tentativas_zero']= "1";
			mysqli_close($conn);
			header('Location:/login');
			exit();
			}
//**************************************************************************************
		else
			{
				$select = "SELECT * FROM `user` WHERE username ='".$_POST['username']. "'";
				$resultado = mysqli_query($conn, $select);
				$linhaça=mysqli_fetch_array($resultado);
				$$linhaça["password"];
				$stored_hash = password_hash($_POST['password'], PASSWORD_ARGON2I, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]);
				$ALGO = explode("$",$stored_hash);
				//print_r($ALGO);
				//exit();
				$parte1 = $ALGO[0].'$'.$ALGO[1].'$'.$ALGO[2].'$'.$ALGO[3];
				//Parte 2 guarda na DB
				//$parte2 = '$'.$ALGO[4].'$'.$ALGO[5];

				$palavra_passe = $parte1.$linhaça["password"];

				if( password_verify($_POST['password'], $palavra_passe)) {
					$update="UPDATE user
									SET shots = 3
									WHERE user.username ='".$_POST['username']."'
									LIMIT 1";
					mysqli_query($conn,$update);

					$_SESSION['permissao_utilizador']= $linhaça["perm_id"];
					$_SESSION['id_utilizador']= $linhaça["id"];
					$_SESSION['utilizador']= $linhaça["username"];
					$_SESSION['fotografia']= $linhaça["pic"];
	//***************marca entrada na tabela dos logs******************************************
					$insert = "INSERT INTO `log`(`user_id`,`datein`)
									VALUES ( '".$_SESSION['id_utilizador']. "'  , NOW() )";
					mysqli_query($conn,$insert);
					mysqli_close($conn);
	//*****************************************************************************************
					if($linhaça["perm_id"]==666)
						{
							header('Location:/admin/dashboard');
							$_SESSION['logado']=1;
						};
					if($linhaça["perm_id"]==699)
						{
							header('Location:/user/dashboard');
						};
					exit();
				}
				else {
						$update="UPDATE user
									SET shots = shots-1
										WHERE username ='".$_POST['username']."'
										LIMIT 1";
						mysqli_query($conn,$update);
						$_SESSION['tentativas_restantes']= $linhaça["shots"]-1;
						$_SESSION['password_errada']= "1";
						if($_SESSION['tentativas_restantes']==0)
							{
							$update="UPDATE user
									SET perm_id = 3
										WHERE username ='".$_POST['username']."'
										LIMIT 1";
							mysqli_query($conn,$update);
							}
						mysqli_close($conn);
						header('Location:/login');
						exit();
				}
		}
	}
?>
