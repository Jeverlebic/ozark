<?php require 'IO/header.php' ?>

    <div class="main">
      <div class="section section-tabs">
        <div class="container">
          <div class="title">
            <h3 class="mb-3"style="text-transform: capitalize; ">Bem-vindo, <?php echo 	$_SESSION['utilizador']; ?> </h3>
          </div>
          <div class="row">
            <div class="col-md-10 ml-auto col-xl-12 mr-auto">
              <div class="mb-3">
                <small class="text-uppercase font-weight-bold">Painel Administrador</small>
              </div>
              <!-- Nav tabs -->
              <div class="card">

                <div class="card-body">
                  <!-- Tab panes -->
                  <div class="container-a1 " style=" margin-left: 20px; margin-right: 20px;  " >
                    <ul class="caption-style-1" >
                      <li style="padding: 20px;" >
                          <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                          <div class="caption">
                            <div class="blur"></div>
                            <div class="caption-text">
                              <h3>SPIDER MAN</h3>
                              <h2>Far From Home</h2>
                              <br>
                              <h2>7.9 ✰</h2>
                              <p></p>
                            </div>
                          </div>
                        </li>

                        <li style="padding: 20px;">
                            <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                            <div class="caption">
                              <div class="blur"></div>
                              <div class="caption-text">
                                <h3>SPIDER MAN</h3>
                                <h2>Far From Home</h2>
                                <br>
                                <h2>7.9 ✰</h2>
                                <p></p>
                              </div>
                            </div>
                          </li>
                          <li style="padding: 20px;">
                              <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                              <div class="caption">
                                <div class="blur"></div>
                                <div class="caption-text">
                                  <h3>SPIDER MAN</h3>
                                  <h2>Far From Home</h2>
                                  <br>
                                  <h2>7.9 ✰</h2>
                                  <p></p>
                                </div>
                              </div>
                            </li>
                            <li style="padding: 20px;">
                                <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                                <div class="caption">
                                  <div class="blur"></div>
                                  <div class="caption-text">
                                    <h3>SPIDER MAN</h3>
                                    <h2>Far From Home</h2>
                                    <br>
                                    <h2>7.9 ✰</h2>
                                    <p></p>
                                  </div>
                                </div>
                              </li>
                              <li style="padding: 20px;">
                                  <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                                  <div class="caption">
                                    <div class="blur"></div>
                                    <div class="caption-text">
                                      <h3>SPIDER MAN</h3>
                                      <h2>Far From Home</h2>
                                      <br>
                                      <h2>7.9 ✰</h2>
                                      <p></p>
                                    </div>
                                  </div>
                                </li>
                                <li style="padding: 20px;">
                                    <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                                    <div class="caption">
                                      <div class="blur"></div>
                                      <div class="caption-text">
                                        <h3>SPIDER MAN</h3>
                                        <h2>Far From Home</h2>
                                        <br>
                                        <h2>7.9 ✰</h2>
                                        <p></p>
                                      </div>
                                    </div>
                                  </li>
                                  <li style="padding: 20px;">
                                      <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                                      <div class="caption">
                                        <div class="blur"></div>
                                        <div class="caption-text">
                                          <h3>SPIDER MAN</h3>
                                          <h2>Far From Home</h2>
                                          <br>
                                          <h2>7.9 ✰</h2>
                                          <p></p>
                                        </div>
                                      </div>
                                    </li>
                                    <li style="padding: 20px;">
                                        <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                                        <div class="caption">
                                          <div class="blur"></div>
                                          <div class="caption-text">
                                            <h3>SPIDER MAN</h3>
                                            <h2>Far From Home</h2>
                                            <br>
                                            <h2>7.9 ✰</h2>
                                            <p></p>
                                          </div>
                                        </div>
                                      </li>
                                      <li style="padding: 20px;">
                                          <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                                          <div class="caption">
                                            <div class="blur"></div>
                                            <div class="caption-text">
                                              <h3>SPIDER MAN</h3>
                                              <h2>Far From Home</h2>
                                              <br>
                                              <h2>7.9 ✰</h2>
                                              <p></p>
                                            </div>
                                          </div>
                                        </li>
                                        <li style="padding: 20px;">
                                            <img src="../assets/img/spider_man.jpg" class="" width="160px" height="240px" alt="" >
                                            <div class="caption">
                                              <div class="blur"></div>
                                              <div class="caption-text">
                                                <h3>SPIDER MAN</h3>
                                                <h2>Far From Home</h2>
                                                <br>
                                                <h2>7.9 ✰</h2>
                                                <p></p>
                                              </div>
                                            </div>
                                          </li>




                        </div>





                      </ul>
                    </div>
                </div>
              </div>
              <button onclick="Esconde()">Inserir Filmes</button>
              <br>
              <br>
              <br>
              <br>
            </div>



            <div class="col-md-10 ml-auto col-xl-12 mr-auto" id="inserir">
              <div class="mb-3">
                <small class="text-uppercase font-weight-bold">Inserir Filmes</small>
              </div>
              <!-- Nav tabs -->
              <div class="card">

                <form class="" action="filmes/inserir_mysql.php" method="post" enctype="multipart/form-data">

                <div class="card-body">

                  <div class="row">
                    <div class="col-sm-6 col-lg-3">
                      <div class="form-group">
                        <input type="text" value="" placeholder=" Título " class="form-control" />
                      </div>
                    </div>

                    <div class="col-sm-1 col-lg-1">
                      <div class="form-group">
                        <input type="text" name="mins" placeholder="min" class="form-control" onkeypress='return event.charCode >= 48 && event.charCode <= 57' maxlength="3">
                      </div>
                    </div>
                    <div class="col-sm-2 col-lg-2">
                      <div class="form-group">
                        <select class="form-control" name="year"  onmousedown="if(this.options.length>3){this.size=3;}"  onchange='this.size=0;' onblur="this.size=0;" >
                          <?php
                           $currentYear = date('Y');
                              foreach (range($currentYear, 1951) as $value) {
                                  echo "<option  >" . $value . "</option > ";
                          }         ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-2 col-lg-2">
                      <div class="form-group">
                        <select name="gender" class="form-control" name="gender" onmousedown="if(this.options.length>3){this.size=3;}"  onchange='this.size=0;' onblur="this.size=0;" required="required">
                         <option value="" style="display:none">Género</option>
                          <?php
                        $select = "SELECT `id`, `desc`
                              FROM `gender` WHERE `del` = 0 ";
                        $resultado = mysqli_query($conn, $select);

                        while ($linha=mysqli_fetch_array($resultado))
                              {
                              echo '<option value="'.$linha["id"].'">'.$linha["desc"].'</option>';

                            };
                        ?>
                      </select>
                      </div>
                    </div>



                    <div class="col-sm-2 col-lg-2">
                      <div class="form-group">
                        <select  class="form-control" name="rank" onmousedown="if(this.options.length>3){this.size=3;}"  onchange='this.size=0;' onblur="this.size=0;" required>
                                <?php
                          for ($i=10;$i>1; $i=$i-0.1)
                            {
                            echo '<option value="'.$i.'">'.$i.'</option>';
                            };

                          ?>
                        </select>
                      </div>
                    </div>




                  </div>
                  <div class="row">

                    <div class="col-sm-5 col-lg-5">
                      <div class="form-group">
                          <input type="text" value="" placeholder=" Link do Youtube " class="form-control" />
                          <textarea style=" " class="form-control" placeholder="Descrição" name="link" maxlength="256" class="form-group dropdown-toggle" /> </textarea>
                      </div>
                    </div>





                  </div>


                    <div class="row">








                      <a type="submit"> wewwes</a>

                      <br>
                      <br>
                      <br>


                    <div class="cold-md-12">


                        <input type="file" class="form-control" name="pic" id="pic">
                          <button type="btn" type="submit">EWEWEWWEEWEWWE</button>
                    </div>

                  </div>


                 </div>
                </div>

                <?php echo $select; ?>

              </form>
                </div>





            <div class="row">


            <div class="col-md-3 ml-1 col-xl-3 mr-auto">
              <div class="mb-3">
                <small class="text-uppercase font-weight-bold">Painel Administrador</small>
              </div>
              <!-- Nav tabs -->
              <div class="card">

                <div class="card-body">
                  <!-- Tab panes -->
                  <br>  <br><br>
                  <br>  <br>
                    <br>
                    <br>
                  <br>
                  <br>  <br><br>
                  <br>  <br>
                    <br>
                    <br>
                  <br>



                </div>
              </div>
            </div>

            <div class="col-md-3 ml-1 col-xl-3 mr-auto">
              <div class="mb-3">
                <small class="text-uppercase font-weight-bold">Painel Administrador</small>
              </div>
              <!-- Nav tabs -->
              <div class="card">

                <div class="card-body">
                  <!-- Tab panes -->
                  <br>  <br><br>
                  <br>  <br>
                    <br>
                    <br>
                  <br>
                  <br>  <br><br>
                  <br>  <br>
                    <br>
                    <br>
                  <br>



                </div>
              </div>
            </div>



            <div class="col-md-3 ml-1 col-xl-3 mr-auto" >
              <div class="mb-3">
                <small class="text-uppercase font-weight-bold">Painel Administrador</small>
              </div>
              <!-- Nav tabs -->
              <div class="card">

                <div class="card-body">
                  <!-- Tab panes -->
                  <br>  <br><br>
                  <br>  <br>
                    <br>
                    <br>
                  <br>
                  <br>  <br><br>
                  <br>  <br>
                    <br>
                    <br>
                  <br>



                </div>
              </div>
            </div>

            </div>

          </div>
        </div>
      </div><!--> SECTION TABS <-->
    </div> <!--> FIM DO MAIN <-->


<?php require 'IO/footer.php' ?>



  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="../assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="../assets/js/core/bootstrap.min.js" type="text/javascript"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
  <script src="../assets/js/plugins/bootstrap-switch.js"></script>
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="../assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Plugin for the DatePicker, full documentation here: https://github.com/uxsolutions/bootstrap-datepicker -->
  <script src="../assets/js/plugins/moment.min.js"></script>
  <script src="../assets/js/plugins/bootstrap-datetimepicker.js" type="text/javascript"></script>
  <!-- Black Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <!-- Control Center for Black UI Kit: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/blk-design-system.min.js?v=1.0.0" type="text/javascript"></script>
  <script>
    $(document).ready(function() {
      blackKit.initDatePicker();
      blackKit.initSliders();
    });

    function scrollToDownload() {

      if ($('.section-download').length != 0) {
        $("html, body").animate({
          scrollTop: $('.section-download').offset().top
        }, 1000);
      }
    }

    //******************************************************************Mostra e esconde

      function Esconde() {
        var x = document.getElementById("inserir");
        if (x.style.display === "none") {
          x.style.display = "block";
        } else {
          x.style.display = "none";
        }
      }




  </script>
</body>

</html>
