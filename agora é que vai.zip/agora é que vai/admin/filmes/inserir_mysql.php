<?php
session_start(); //para utilizar "session" tem de estar aqui no topo e em todos os scripts
//*************************************para eliminar a variável session $_SESSION['permissao'] depois de logout******
//******evita que se introduza diretamento o link no browser e entre*******
if (!isset($_POST['title']))
	{
		header('Location:/dashboard');
		exit();
	}
//*************************************************************************
include ($_SERVER['DOCUMENT_ROOT']."/database.php"); //script de acesso à base de dados
//******************************deteta se o user está eliminado********************************
$select = "SELECT title , del  FROM movie
			WHERE title ='".$_POST['title']. "'
			AND del = 1	LIMIT 1";
$resultado = mysqli_query ($conn, $select);
$numero_de_linhas = mysqli_num_rows($resultado);
if($numero_de_linhas==1)
	{
		$_SESSION['utilizador_eliminado']= "1";
		mysqli_close($conn);
		header('Location:/dashboard');
		exit();
	}
//*************************************************************************************

$insert = " INSERT INTO `movie`(`title`, `year`, `mins`, `desc`, `rank`, `gender_id`, `user_id`, `del`)
            VALUES ('".$_POST['title']. "','".$_POST['year']. "','".$_POST['mins']. "','".$_POST['desc']. "',
                    '".$_POST['rank']. "','".$_POST['gender']. "', '".$_SESSION['id_utilizador']. "',0) ";

$resultado = mysqli_query($conn, $insert);


$extensao_ficheiro = (pathinfo($_FILES["pic"]["name"],PATHINFO_EXTENSION));
//****************************upload imagerm*********************
$target_dir = $_SERVER['DOCUMENT_ROOT']."./assets/img/filmes/".$_POST['title'];
$target_file = $target_dir.$_POST['title'].".".$extensao_ficheiro;

//$target_file = $target_dir . basename($_FILES["pic"]["name"]);
move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file);

$update="UPDATE `movie` SET `pic` = '".$_POST['title'].".".$extensao_ficheiro."'
          WHERE `title` ='".$_POST['title']."'  LIMIT 1";

mysqli_query($conn,$update);
$_SESSION['filme_inserido']=1;
header('Location:/admin/dashboard');
exit();
//*****************************************************************
