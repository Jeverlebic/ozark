-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 31-Maio-2019 às 01:17
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `torettos`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `comment` varchar(256) DEFAULT NULL,
  `likes` int(11) DEFAULT NULL,
  `dislikes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `gender`
--

CREATE TABLE `gender` (
  `id` int(11) NOT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `gender`
--

INSERT INTO `gender` (`id`, `desc`, `del`) VALUES
(1, 'Ação', 0),
(2, 'Comédia', 0),
(3, 'DSww', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `job`
--

CREATE TABLE `job` (
  `id` int(11) NOT NULL,
  `job` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `job`
--

INSERT INTO `job` (`id`, `job`) VALUES
(1, 'Actor'),
(2, 'Realizador');

-- --------------------------------------------------------

--
-- Estrutura da tabela `lock`
--

CREATE TABLE `lock` (
  `id` int(11) NOT NULL,
  `type` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `lock`
--

INSERT INTO `lock` (`id`, `type`) VALUES
(0, 'Ativo'),
(1, 'Bloqueado'),
(2, 'S/ Tentativas');

-- --------------------------------------------------------

--
-- Estrutura da tabela `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `datein` datetime DEFAULT NULL,
  `dateout` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `log`
--

INSERT INTO `log` (`id`, `datein`, `dateout`, `user_id`) VALUES
(18, '2019-05-26 15:24:18', '2019-05-26 15:24:23', 7),
(19, '2019-05-26 15:24:35', '2019-05-26 15:24:40', 1),
(20, '2019-05-26 15:26:04', NULL, 8),
(21, '2019-05-28 19:41:45', NULL, 1),
(22, '2019-05-28 19:47:29', NULL, 1),
(23, '2019-05-28 19:51:21', '2019-05-28 19:55:27', 1),
(24, '2019-05-29 18:56:50', NULL, 1),
(25, '2019-05-29 19:09:01', NULL, 1),
(26, '2019-05-29 20:38:33', NULL, 1),
(27, '2019-05-29 20:42:20', NULL, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `movie`
--

CREATE TABLE `movie` (
  `id` int(11) NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `mins` int(11) DEFAULT NULL,
  `desc` varchar(512) DEFAULT NULL,
  `rank` decimal(3,1) DEFAULT NULL,
  `pic` varchar(45) DEFAULT NULL,
  `gender_id` int(11) DEFAULT NULL,
  `trailer` varchar(256) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `del` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `movie_has_comment`
--

CREATE TABLE `movie_has_comment` (
  `movie_id` int(11) DEFAULT NULL,
  `comment_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `movie_has_people`
--

CREATE TABLE `movie_has_people` (
  `movie_id` int(11) DEFAULT NULL,
  `people_id` int(11) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `actor1` varchar(45) DEFAULT NULL,
  `actor2` varchar(45) DEFAULT NULL,
  `actor3` varchar(45) DEFAULT NULL,
  `dir1` varchar(45) DEFAULT NULL,
  `dir2` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `people`
--

CREATE TABLE `people` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `bio` varchar(512) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `perm`
--

CREATE TABLE `perm` (
  `id` int(11) NOT NULL,
  `perm` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `perm`
--

INSERT INTO `perm` (`id`, `perm`) VALUES
(666, 'Administrador'),
(699, 'Utilizador');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(512) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `shots` int(11) DEFAULT NULL,
  `pic` varchar(45) DEFAULT NULL,
  `del` int(11) DEFAULT NULL,
  `perm_id` int(11) DEFAULT NULL,
  `lock_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `shots`, `pic`, `del`, `perm_id`, `lock_id`) VALUES
(1, 'doutor', '$cWw5ZlJzOFAvQmhyalJjdA$5WVuWUXWIHZ218qAcxn5R8N3sB/5pWdeetGkUSJ6sSg', 'danielalves555.da@hotmail.com', 3, '3.jpg', 0, 666, 0),
(7, 'daniel', '$cWw5ZlJzOFAvQmhyalJjdA$5WVuWUXWIHZ218qAcxn5R8N3sB/5pWdeetGkUSJ6sSg', 'danielalves555.da@gmail.com', 3, '3.jpg', 0, 666, 0),
(8, 'menino', '$NTZMeVY0LjJkVVpma2xKWg$RjhtrFHlXLz+LK9bSjzEv5faIwwq0eUhHN5W9bzzQWc', 'meninos@volta.fogueira', 3, NULL, 0, 699, 0),
(9, 'dddd', '$ZWxqekRmTGd5YUJUVlNzcQ$YwKgGUT+JdoHO95mhXZloRB6gBtJNpzzXezUIZi7+W0', '12321231@123321.com', 3, NULL, 0, 699, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lock`
--
ALTER TABLE `lock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_log_user1_idx` (`user_id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_movie_gender_idx` (`gender_id`),
  ADD KEY `fk_movie_user1_idx` (`user_id`);

--
-- Indexes for table `movie_has_comment`
--
ALTER TABLE `movie_has_comment`
  ADD KEY `fk_movie_has_comment_comment1_idx` (`comment_id`),
  ADD KEY `fk_movie_has_comment_movie1_idx` (`movie_id`);

--
-- Indexes for table `movie_has_people`
--
ALTER TABLE `movie_has_people`
  ADD KEY `fk_movie_has_people_people1_idx` (`people_id`),
  ADD KEY `fk_movie_has_people_movie1_idx` (`movie_id`);

--
-- Indexes for table `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_people_job1_idx` (`job_id`);

--
-- Indexes for table `perm`
--
ALTER TABLE `perm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_perm1_idx` (`perm_id`),
  ADD KEY `fk_user_lock1_idx` (`lock_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `people`
--
ALTER TABLE `people`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `perm`
--
ALTER TABLE `perm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=700;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `log`
--
ALTER TABLE `log`
  ADD CONSTRAINT `fk_log_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `movie`
--
ALTER TABLE `movie`
  ADD CONSTRAINT `fk_movie_gender` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_movie_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `movie_has_comment`
--
ALTER TABLE `movie_has_comment`
  ADD CONSTRAINT `fk_movie_has_comment_comment1` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_movie_has_comment_movie1` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `movie_has_people`
--
ALTER TABLE `movie_has_people`
  ADD CONSTRAINT `fk_movie_has_people_movie1` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_movie_has_people_people1` FOREIGN KEY (`people_id`) REFERENCES `people` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `people`
--
ALTER TABLE `people`
  ADD CONSTRAINT `fk_people_job1` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_lock1` FOREIGN KEY (`lock_id`) REFERENCES `lock` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_user_perm1` FOREIGN KEY (`perm_id`) REFERENCES `perm` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
