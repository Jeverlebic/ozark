register﻿<?php
session_start(); //para utilizar "session" tem de estar aqui no topo e em todos os scripts
//*************************************para eliminar a variável session $_SESSION['permissao'] depois de logout******

//******evita que se introduza diretamento o link no browser e entre*******
if (!isset($_POST['username']))
	{
		header('Location:/register');
		exit();
	}

//*************************************************************************

include ($_SERVER['DOCUMENT_ROOT']."/database.php"); //script de acesso à base de dados

//******************************deteta se o user existe********************************
$select = "SELECT
				username
			FROM
				user
			WHERE username ='".$_POST['username']. "'
			LIMIT 1" ;
$resultado = mysqli_query($conn, $select);
$numero_de_linhas = mysqli_num_rows($resultado);

if($numero_de_linhas==0)
	{
		if( $_POST['password'] == $_POST['password2'] )
		{
			$stored_hash = password_hash($_POST['password'], PASSWORD_ARGON2I, ['memory_cost' => 2048, 'time_cost' => 4, 'threads' => 3]);
			//Works for both bcrypt and Argon2
			$ALGO = explode("$",$stored_hash);
			//print_r($ALGO);
			//exit();
			$parte1 = $ALGO[0].'$'.$ALGO[1].'$'.$ALGO[2].'$'.$ALGO[3];
			//Parte 2 guarda na DB

			$parte2 = '$'.$ALGO[4].'$'.$ALGO[5];
			if(password_verify( $_POST['password'], $stored_hash)) {
			 // password validated
			$insert = "INSERT INTO `user`(`username`, `password`, `email`, `shots`, `del`, `perm_id`, `lock_id`)
						VALUES ('".$_POST['username']. "', '".$parte2. "' , '".$_POST['email']. "',3,0,699,0)";
			$resultado = mysqli_query($conn, $insert);
			$_SESSION['user'] = $_POST['username'];

			$_SESSION['registado']=1;
			header('Location:/login.php');

				}
				echo "isto nao verifica jovem";
				exit();
		}
		else //password != password 2
		{
			$_SESSION['passwords_diferentes']= "1";
			mysqli_close($conn);
			header('Location:/register');
			exit();

		}
	}

else
	{
		$_SESSION['utilizador_ja_existe']= "1";
		mysqli_close($conn);
		header('Location:/register');
		exit();
	}


?>
